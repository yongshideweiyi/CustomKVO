//
//  Person.m
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import "Person.h"

@implementation Person
- (void)dealloc {
    NSLog(@"%s", __func__);
}
@end
