//
//  Person.h
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject {
    NSString *name;
}
@property (nonatomic, copy) NSString *nickName;
@property (nonatomic, copy) NSString *realName;
@end

NS_ASSUME_NONNULL_END
