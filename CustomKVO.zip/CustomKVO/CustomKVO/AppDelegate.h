//
//  AppDelegate.h
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

