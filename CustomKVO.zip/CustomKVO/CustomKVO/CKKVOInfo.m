//
//  CKKVOInfo.m
//  CustomKVO
//
//  Created by wbx on 2021/10/12.
//

#import "CKKVOInfo.h"

@implementation CKKVOInfo
- (instancetype)initWithObserver:(NSObject *)observer
                      forKeyPath:(NSString *)keyPath
                         options:(CKKeyValueObservingOptions)options {
    self = [super init];
    if (self) {
        self.observer = observer;
        self.keyPath = keyPath;
        self.options = options;
    }
    return self;
}
@end
