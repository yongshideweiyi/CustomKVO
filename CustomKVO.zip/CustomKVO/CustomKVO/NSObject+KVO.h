//
//  NSObject+KVO.h
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import <Foundation/Foundation.h>
#import "CKKVOInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (KVO)
- (void)ck_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath options:(CKKeyValueObservingOptions)options context:(nullable void *)context;
- (void)ck_observeValueForKeyPath:(nullable NSString *)keyPath ofObject:(nullable id)object change:(nullable NSDictionary<NSKeyValueChangeKey, id> *)change context:(nullable void *)context;
- (void)ck_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath;
@end

NS_ASSUME_NONNULL_END
