//
//  CKKVOInfo.h
//  CustomKVO
//
//  Created by wbx on 2021/10/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^CKKVOBlock)(id observer, NSString *keyPath, id oldValue, id newValue);

typedef NS_OPTIONS(NSUInteger, CKKeyValueObservingOptions) {
    CKKeyValueObservingOptionNew = 0x01,
    CKKeyValueObservingOptionOld = 0x02,
};

@interface CKKVOInfo : NSObject
@property (nonatomic, copy) NSString *keyPath;
@property (nonatomic, weak) NSObject *observer; // 需要使用weak修饰，否则会发生循环引用
@property (nonatomic,copy) CKKVOBlock handleBlock; // block形式
/// block形式初始化方法
/// @param observer observer description
/// @param keyPath keyPath description
/// @param block handleBlock description
- (instancetype)initWithObserver:(NSObject *)observer
                      forKeyPath:(NSString *)keyPath
                     handleBlock:(CKKVOBlock)block;
@end

NS_ASSUME_NONNULL_END
