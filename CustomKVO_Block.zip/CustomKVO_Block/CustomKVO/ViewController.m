//
//  ViewController.m
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import "ViewController.h"
#import "Person.h"
#import "NSObject+KVO.h"
#import <objc/runtime.h>

@interface ViewController ()
@property (nonatomic, strong) Person *person;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor whiteColor];

    self.person = [[Person alloc] init];
    self.person.nickName = @"ck";


    /*[self.person ck_addObserver:self forKeyPath:@"nickName" options:CKKeyValueObservingOptionNew | CKKeyValueObservingOptionOld context:NULL];
    [self.person ck_addObserver:self forKeyPath:@"realName" options:CKKeyValueObservingOptionNew | CKKeyValueObservingOptionOld context:NULL];*/

    [self.person ck_addObserver:self forKeyPath:@"nickName" block:^(id  _Nonnull observer, NSString * _Nonnull keyPath, id  _Nonnull oldValue, id  _Nonnull newValue) {
        NSLog(@"keyPath:%@--old:%@--new:%@", keyPath, oldValue, newValue);
    }];
    [self.person ck_addObserver:self forKeyPath:@"realName" block:^(id  _Nonnull observer, NSString * _Nonnull keyPath, id  _Nonnull oldValue, id  _Nonnull newValue) {
        NSLog(@"keyPath:%@--old:%@--new:%@", keyPath, oldValue, newValue);
    }];

    self.person.realName = @"张三";
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.person.nickName = [NSString stringWithFormat:@"%@ -", self.person.nickName];
    self.person.realName = [NSString stringWithFormat:@"%@ -", self.person.realName];
}

- (void)dealloc {
    //[self.person ck_removeObserver:self forKeyPath:@"nickName"];
    //[self.person ck_removeObserver:self forKeyPath:@"realName"];
    NSLog(@"%s", __func__);
}

@end
