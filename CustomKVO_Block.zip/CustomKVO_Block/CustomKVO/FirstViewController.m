//
//  FirstViewController.m
//  CustomKVO
//
//  Created by wbx on 2021/10/12.
//

#import "FirstViewController.h"
#import "ViewController.h"

@interface FirstViewController ()
@property (weak, nonatomic) IBOutlet UIButton *pushBtn;

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}
- (IBAction)pushBtnClick:(id)sender {
    ViewController *view = [[ViewController alloc] init];
    view.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:view animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
