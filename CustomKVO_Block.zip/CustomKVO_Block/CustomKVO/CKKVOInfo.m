//
//  CKKVOInfo.m
//  CustomKVO
//
//  Created by wbx on 2021/10/12.
//

#import "CKKVOInfo.h"

@implementation CKKVOInfo
- (instancetype)initWithObserver:(NSObject *)observer
                      forKeyPath:(NSString *)keyPath
                     handleBlock:(CKKVOBlock)block {
    self = [super init];
    if (self) {
        self.observer = observer;
        self.keyPath = keyPath;
        self.handleBlock = block;
    }
    return self;
}
@end
