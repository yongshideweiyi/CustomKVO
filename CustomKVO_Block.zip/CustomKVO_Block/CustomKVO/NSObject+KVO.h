//
//  NSObject+KVO.h
//  CustomKVO
//
//  Created by wbx on 2021/10/9.
//

#import <Foundation/Foundation.h>
#import "CKKVOInfo.h"

NS_ASSUME_NONNULL_BEGIN



@interface NSObject (KVO)
- (void)ck_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath block:(CKKVOBlock)block;
- (void)ck_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath;
@end

NS_ASSUME_NONNULL_END
